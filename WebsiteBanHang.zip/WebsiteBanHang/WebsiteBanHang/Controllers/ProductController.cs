﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebsiteBanHang.Models;
using WebsiteBanHang.Repositories;

namespace WebsiteBanHang.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly IWebHostEnvironment _webHostEnvironment; // Khai báo môi trường ứng dụng

        // Inject dịch vụ IWebHostEnvironment vào Constructor
        public ProductController(IProductRepository productRepository, ICategoryRepository categoryRepository, IWebHostEnvironment webHostEnvironment)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            var products = _productRepository.GetAll();
            return View(products);
        }

        public IActionResult Display(int id)
        {
            var product = _productRepository.GetById(id);
            if (product == null) return NotFound();
            return View(product);
        }

        public IActionResult Add()
        {
            var categories = _categoryRepository.GetAllCategories();
            ViewBag.Categories = new SelectList(categories, "Id", "Name");
            return View();
        }

        // Xử lý dữ liệu thêm sản phẩm kèm upload file
        [HttpPost]
        public async Task<IActionResult> Add(Product product, IFormFile Image)
        {
            if (ModelState.IsValid)
            {
                if (Image != null && Image.Length > 0)
                {
                    // Hàm SaveImage xử lý việc lưu file và trả về đường dẫn URL
                    product.ImageUrl = await SaveImage(Image);
                }

                _productRepository.Add(product);
                return RedirectToAction(nameof(Index));
            }

            var categories = _categoryRepository.GetAllCategories();
            ViewBag.Categories = new SelectList(categories, "Id", "Name");
            return View(product);
        }

        public IActionResult Update(int id)
        {
            var product = _productRepository.GetById(id);
            if (product == null) return NotFound();

            var categories = _categoryRepository.GetAllCategories();
            ViewBag.Categories = new SelectList(categories, "Id", "Name", product.CategoryId);
            return View(product);
        }

        // Xử lý dữ liệu cập nhật sản phẩm kèm đổi ảnh
        [HttpPost]
        public async Task<IActionResult> Update(Product product, IFormFile Image)
        {
            if (ModelState.IsValid)
            {
                if (Image != null && Image.Length > 0)
                {
                    // Nếu người dùng tải ảnh mới lên, xử lý lưu ảnh mới và cập nhật URL
                    product.ImageUrl = await SaveImage(Image);
                }

                _productRepository.Update(product);
                return RedirectToAction(nameof(Index));
            }

            var categories = _categoryRepository.GetAllCategories();
            ViewBag.Categories = new SelectList(categories, "Id", "Name", product.CategoryId);
            return View(product);
        }

        public IActionResult Delete(int id)
        {
            var product = _productRepository.GetById(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        public IActionResult DeleteConfirmed(int id)
        {
            _productRepository.Delete(id);
            return RedirectToAction(nameof(Index));
        }

        // Hàm helper dùng để xử lý lưu file ảnh vào thư mục wwwroot/images
        private async Task<string> SaveImage(IFormFile image)
        {
            // Tạo tên file duy nhất bằng cách kết hợp chuỗi ngẫu nhiên Guid và tên file gốc
            var fileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(image.FileName);

            // Tìm đường dẫn vật lý tuyệt đối đến thư mục wwwroot/images
            var path = Path.Combine(_webHostEnvironment.WebRootPath, "images", fileName);

            // Ghi file vào ổ đĩa cứng của máy chủ/máy tính chạy ứng dụng
            using (var stream = new FileStream(path, FileMode.Create))
            {
                await image.CopyToAsync(stream);
            }

            // Trả về đường dẫn tương đối dạng URL để lưu vào Database phục vụ việc hiển thị
            return "/images/" + fileName;
        }
    }
}