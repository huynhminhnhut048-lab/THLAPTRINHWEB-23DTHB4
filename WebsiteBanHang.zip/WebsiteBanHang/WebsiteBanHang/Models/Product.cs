﻿using System.ComponentModel.DataAnnotations;

namespace WebsiteBanHang.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string? Name { get; set; }

        [Range(0.01, 100000.00)]
        public decimal Price { get; set; }

        public string? Description { get; set; }

        public int CategoryId { get; set; }

        // Thêm dòng này để lưu đường dẫn file ảnh sản phẩm
        public string? ImageUrl { get; set; }
    }
}