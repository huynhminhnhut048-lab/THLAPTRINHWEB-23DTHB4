﻿using System.ComponentModel.DataAnnotations;

namespace WebsiteBanHang.Models
{
    // Category.cs
    public class Category
    {
        public int Id { get; set; }
        [Required, StringLength(50)]
        public string ?Name { get; set; }
    }
}
